//
//  ViewController.m
//  RestDemo
//
//  Created by jittu on 8/29/13.
//  Copyright (c) 2013 jittu. All rights reserved.
//

#import "ViewController.h"
#import <RestKit/RestKit.h>
#import "ViewController.h"
#import "Token.h"
#import "User.h"
#import <RestKit/Testing.h>
#import "ResponseObj.h"
#import "Object.h"
#import "Version.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
     NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    [prefs setValue:@"2013-06-01" forKey:@"version_date"];
    RKObjectManager *manager = [RKObjectManager managerWithBaseURL:[NSURL URLWithString:[prefs stringForKey:@"webAPI"]]];
    [RKObjectManager setSharedManager:manager];
    NSLog(@"token check==%@",[prefs stringForKey:@"token"]);
    [[manager HTTPClient] setDefaultHeader:@"token" value:[prefs stringForKey:@"token"]];
    [[manager HTTPClient] setDefaultHeader:@"versioDate" value:[prefs valueForKey:@"version_date"]];
    
    manager.requestSerializationMIMEType=RKMIMETypeJSON;
    version_date=[[NSDictionary alloc] initWithObjectsAndKeys:@"2013-06-01",@"v1",@"2013-01-30",@"v2",@"2012-07-01",@"v3",nil];
    NSLog(@"version date==%@",[version_date valueForKey:@"v1"]);
    
    [segmentedControl addTarget:self action:@selector(didChangeSegmentControl:) forControlEvents:UIControlEventValueChanged];
    [self SettingMapping];
	// Do any additional setup after loading the view, typically from a nib.
}

-(id)getUserObject
{

    
    NSString *tmpdate= [[[RKObjectManager sharedManager] defaultHeaders] valueForKey:@"versioDate"];
    NSLog(@"tmpdate===%@",tmpdate);
    id user_obj;
    if([tmpdate isEqualToString:@"2013-06-01"])
    {
        user_obj=[Version get_UserObject_BasedonDate:fname.text mname:mname.text lname:lname.text userid:userid.text];
            NSLog(@"testing object here with middle name version 1 objet");
        
    }
    else if ([tmpdate isEqualToString:@"2013-01-30"])
    {
        user_obj=[Version get_UserObject_BasedonDate:fname.text  lname:lname.text userid:userid.text];
         NSLog(@"testing object here without middle name version 2 objet");
        
    }
    else if ([tmpdate isEqualToString:@"2012-07-01"])
    {
        user_obj=[Version get_UserObject_BasedonDate:fname.text mname:mname.text lname:lname.text address:address.text userid:userid.text];
         NSLog(@"testing object here with middle name & address version 3 objet");
    }
    
    

    
    return user_obj;
}

-(void)SettingMapping
{
    RKObjectMapping* UserMapping=[RKObjectMapping requestMapping];
    UserMapping = [RKObjectMapping mappingForClass:[UserDetail class]];
    [UserMapping addAttributeMappingsFromArray:@[ @"firstName", @"middleName", @"lastName",@"userId" ]];
    
    RKObjectMapping* UserMapping2=[RKObjectMapping requestMapping];
    UserMapping2 = [RKObjectMapping mappingForClass:[UserDetail2 class]];
    [UserMapping2 addAttributeMappingsFromArray:@[ @"firstName", @"lastName",@"userId"]];

    RKObjectMapping* UserMapping3=[RKObjectMapping requestMapping];
    UserMapping3 = [RKObjectMapping mappingForClass:[UserDetail3 class]];
    [UserMapping3 addAttributeMappingsFromArray:@[ @"firstName", @"middleName",@"lastName",@"address",@"userId"]];
    
    
    ////////////// Creating a User ////
   
   // id user_obj=[self getUserObject];
    
    UserDetail *userdetail=[Version get_UserObject_BasedonDate:fname.text mname:mname.text lname:lname.text userid:userid.text];
    UserDetail2 *userdetail2=[Version get_UserObject_BasedonDate:fname.text  lname:lname.text userid:userid.text];
    UserDetail3 *userdetail3=[Version get_UserObject_BasedonDate:fname.text mname:mname.text lname:lname.text address:@"address" userid:userid.text];
    
    RKObjectMapping *requestMapping1 = [RKObjectMapping requestMapping];
[requestMapping1 addAttributeMappingsFromArray:@[@"firstName",@"middleName",@"lastName",@"userId"]];
   
    RKObjectMapping *requestMapping2 = [RKObjectMapping requestMapping];
[requestMapping2 addAttributeMappingsFromArray:@[ @"firstName", @"lastName",@"userId"]];
    
    RKObjectMapping *requestMapping3 = [RKObjectMapping requestMapping];
[requestMapping3 addAttributeMappingsFromArray:@[ @"firstName", @"middleName",@"lastName",@"address",@"userId"]];
    
//requestMapping=[Version get_UserRequestMapping_Date:[[NSUserDefaults standardUserDefaults] valueForKey:@"version_date"] UserMapping:requestMapping];
    
    RKRequestDescriptor *requestDescriptor = [RKRequestDescriptor requestDescriptorWithMapping:requestMapping1 objectClass:[userdetail class] rootKeyPath:nil method:RKRequestMethodAny];
    [[RKObjectManager sharedManager] addRequestDescriptor:requestDescriptor];
    
    RKRequestDescriptor *requestDescriptor2 = [RKRequestDescriptor requestDescriptorWithMapping:requestMapping2 objectClass:[userdetail2 class] rootKeyPath:nil method:RKRequestMethodAny];
    
    RKRequestDescriptor *requestDescriptor3 = [RKRequestDescriptor requestDescriptorWithMapping:requestMapping3 objectClass:[userdetail3 class] rootKeyPath:nil method:RKRequestMethodAny];
    
    [[RKObjectManager sharedManager] addRequestDescriptor:requestDescriptor];
    [[RKObjectManager sharedManager] addRequestDescriptor:requestDescriptor2];
    [[RKObjectManager sharedManager] addRequestDescriptor:requestDescriptor3];
    
    
    
    RKResponseDescriptor *responseDescriptor = [RKResponseDescriptor responseDescriptorWithMapping:UserMapping pathPattern:nil keyPath:@"object" statusCodes:RKStatusCodeIndexSetForClass(RKStatusCodeClassSuccessful)];
    RKResponseDescriptor *responseDescriptor2 = [RKResponseDescriptor responseDescriptorWithMapping:UserMapping2 pathPattern:nil keyPath:@"object" statusCodes:RKStatusCodeIndexSetForClass(RKStatusCodeClassSuccessful)];
    RKResponseDescriptor *responseDescriptor3 = [RKResponseDescriptor responseDescriptorWithMapping:UserMapping3 pathPattern:nil keyPath:@"object" statusCodes:RKStatusCodeIndexSetForClass(RKStatusCodeClassSuccessful)];
    
   
        [[RKObjectManager sharedManager] addResponseDescriptor:responseDescriptor];
    [[RKObjectManager sharedManager] addResponseDescriptor:responseDescriptor2];
    [[RKObjectManager sharedManager] addResponseDescriptor:responseDescriptor3];
   
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
    
}

-(IBAction)getUser:(id)sender
{
    

    RKObjectMapping* UserMapping=[RKObjectMapping requestMapping];
    UserMapping=[Version get_User_BasedonDate:[[NSUserDefaults standardUserDefaults] valueForKey:@"version_date"] UserMapping:UserMapping];
    
    RKObjectMapping* ObjectMapping = [RKObjectMapping mappingForClass:[Object class]];
    [ObjectMapping addAttributeMappingsFromDictionary:@{
     @"message": @"message",
     @"status": @"status"
     }];
    [ObjectMapping addPropertyMapping:[RKRelationshipMapping relationshipMappingFromKeyPath:@"object" toKeyPath:@"object" withMapping:UserMapping]];
    
    RKResponseDescriptor *responseDescriptor = [RKResponseDescriptor responseDescriptorWithMapping:UserMapping pathPattern:nil keyPath:@"object" statusCodes:RKStatusCodeIndexSetForClass(RKStatusCodeClassSuccessful)];
    NSLog(@"tesing response desc==%@",[responseDescriptor description]);
    
    NSString *getuserURL=[NSString stringWithFormat:NSLocalizedString(@"get_user",@""),[userid text]];
    
    [[RKObjectManager sharedManager] addResponseDescriptor:responseDescriptor];
    [[RKObjectManager sharedManager] getObject:UserMapping path:getuserURL parameters:nil success:^(RKObjectRequestOperation *operation, RKMappingResult *mappingResult) {
        NSLog(@"%@===testing", mappingResult.firstObject);
        
        
        if(mappingResult.firstObject!=nil)
        {
            [self SettingValues:mappingResult.firstObject];
        }
        else
        {
            NSLog(@"null value");
        }
    } failure:^(RKObjectRequestOperation *operation, NSError *error) {
        
    }];
    


}



-(void)SettingValues:(id)user_obj{
    NSString *tmpdate= [[[RKObjectManager sharedManager] defaultHeaders] valueForKey:@"versioDate"];
    NSLog(@"tmpdate===%@",tmpdate);
    if([tmpdate isEqualToString:@"2013-06-01"])
    {
        UserDetail *tmp=(UserDetail*)user_obj;
        NSLog(@"dost chal ja==%@",tmp.firstName);
        if(tmp.firstName!=nil)
            fname.text=tmp.firstName;
        if(tmp.middleName!=nil)
            mname.text=tmp.middleName;
        if(tmp.lastName!=nil)
            lname.text=tmp.lastName;
        
    }
    else if ([tmpdate isEqualToString:@"2013-01-30"])
    {
        UserDetail2 *tmp=(UserDetail2*)user_obj;
        if(tmp.firstName!=nil)
            fname.text=tmp.firstName;
        if(tmp.lastName!=nil)
            lname.text=tmp.lastName;
    }
    else if ([tmpdate isEqualToString:@"2012-07-01"])
    {
        UserDetail3 *tmp=(UserDetail3*)user_obj;
        NSLog(@"dost chal ja==%@",tmp.firstName);
        if(tmp.firstName!=nil)
            fname.text=tmp.firstName;
        if(tmp.middleName!=nil)
            mname.text=tmp.middleName;
        if(tmp.lastName!=nil)
            lname.text=tmp.lastName;
        if(tmp.address!=nil)
            address.text=tmp.address;
        
    }
    
}



-(IBAction)createUser:(id)sender{

    RKObjectManager *manager=[RKObjectManager sharedManager];
    RKObjectMapping* ResponseMapping = [RKObjectMapping mappingForClass:[ResponseObj class]];
    [ResponseMapping addAttributeMappingsFromArray:@[ @"message", @"object", @"status" ]];
    
    id user_obj=[self getUserObject];
  
    [manager postObject:user_obj path:NSLocalizedString(@"create_user",@"") parameters:nil success:^(RKObjectRequestOperation *operation, RKMappingResult *mappingResult) {
        NSLog(@"sfsfsfds==%@",mappingResult.array);
        
        UserDetail *tmp=mappingResult.firstObject;

        NSLog(@"status==%@",tmp.firstName);
        userid.text=[NSString stringWithFormat:@"%d",tmp.userId];
       // newuser.text=[NSString stringWithFormat:@"%d: %@ %@ %@",tmp.userId,tmp.firstName,tmp.middleName,tmp.lastName];
    } failure:^(RKObjectRequestOperation *operation, NSError *error) {
        NSLog(@"sfsfsfds=error");
    }];


}

-(IBAction)sendPush:(id)sender{
    // NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    RKObjectManager *manager=[RKObjectManager sharedManager];
   // [[manager HTTPClient] setDefaultHeader:@"to" value:[prefs stringForKey:@"deviceToken"]];
    RKObjectMapping* UserMapping=[RKObjectMapping requestMapping];
    UserMapping=[Version get_User_BasedonDate:[[NSUserDefaults standardUserDefaults] valueForKey:@"version_date"] UserMapping:UserMapping];
   
    NSString *sendPush=[NSString stringWithFormat:NSLocalizedString(@"push",@""),[pushmsg text]];
    
    [manager getObject:UserMapping path:sendPush parameters:nil success:^(RKObjectRequestOperation *operation, RKMappingResult *mappingResult) {
        NSLog(@"%@===testing", mappingResult.firstObject);
        
    
    } failure:^(RKObjectRequestOperation *operation, NSError *error) {
        
    }];

}


-(IBAction)UpdateUser:(id)sender{
    
    RKObjectManager *manager=[RKObjectManager sharedManager];
    RKObjectMapping* ResponseMapping = [RKObjectMapping mappingForClass:[ResponseObj class]];
    [ResponseMapping addAttributeMappingsFromArray:@[ @"message", @"object", @"status" ]];
    
    RKObjectMapping* UserMapping=[RKObjectMapping requestMapping];
    UserMapping = [RKObjectMapping mappingForClass:[UserDetail class]];
    [UserMapping addAttributeMappingsFromArray:@[ @"firstName", @"middleName", @"lastName",@"userId" ]];
    
    ////////////// Creating a User ////
    
    NSString *tmpdate= [[[RKObjectManager sharedManager] defaultHeaders] valueForKey:@"versioDate"];
    NSLog(@"tmpdate===%@",tmpdate);
    //id user_obj=[self getUserObject];
    
     UserDetail *user_obj=[Version get_UserObject_BasedonDate:fname.text mname:mname.text lname:lname.text userid:userid.text];
    
    RKObjectMapping *requestMapping = [RKObjectMapping requestMapping];
  //  requestMapping=[Version get_UserRequestMapping_Date:[[NSUserDefaults standardUserDefaults] valueForKey:@"version_date"] UserMapping:requestMapping];
    [requestMapping addAttributeMappingsFromArray:@[@"firstName",@"middleName" @"lastName",@"userId"]];
    
    RKResponseDescriptor *responseDescriptor = [RKResponseDescriptor responseDescriptorWithMapping:UserMapping pathPattern:nil keyPath:@"object" statusCodes:RKStatusCodeIndexSetForClass(RKStatusCodeClassSuccessful)];
    [[RKObjectManager sharedManager] addResponseDescriptor:responseDescriptor];
    
    [manager postObject:user_obj path:NSLocalizedString(@"update_user",@"") parameters:nil success:^(RKObjectRequestOperation *operation, RKMappingResult *mappingResult) {
        NSLog(@"sfsfsfds==test%@",mappingResult.array);
       
    } failure:^(RKObjectRequestOperation *operation, NSError *error) {
        NSLog(@"sfsfsfds=error");
    }];
    
}

-(IBAction)deleteUser:(id)sender{
    
   
    RKObjectMapping* ResponseMapping = [RKObjectMapping mappingForClass:[ResponseObj class]];
    [ResponseMapping addAttributeMappingsFromArray:@[ @"message", @"object", @"status" ]];
    
    
    RKObjectMapping* UserMapping = [RKObjectMapping mappingForClass:[UserDetail class]];
    [UserMapping addAttributeMappingsFromArray:@[ @"firstName", @"middleName", @"lastName",@"userId" ]];
    
    
    ////////////// Creating a User ////
    
    UserDetail *newsuer=[UserDetail new];
    [newsuer setFirstName:fname.text];
    [newsuer setMiddleName:mname.text];
    [newsuer setLastName:lname.text];
    [newsuer setUserId:[[userid text] intValue]];
    
    RKObjectMapping *requestMapping = [RKObjectMapping requestMapping];
    [requestMapping addAttributeMappingsFromArray:@[@"firstName", @"middleName", @"lastName",@"userId"]];
    
    
    NSString *deleteuserURL=[NSString stringWithFormat:NSLocalizedString(@"delete_user",@""),[userid text]];
    
    
    [[RKObjectManager sharedManager] getObject:nil path:deleteuserURL parameters:nil success:^(RKObjectRequestOperation *operation, RKMappingResult *mappingResult) {
        NSLog(@"user deleted==%@",mappingResult.array);
    } failure:^(RKObjectRequestOperation *operation, NSError *error) {
         NSLog(@"user deleted erro");
    }];

    
}





- (IBAction)didChangeSegmentControl:(UISegmentedControl *)control
{
    // To get string: [control titleForSegmentAtIndex:control.selectedSegmentIndex]
     NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    if (control.selectedSegmentIndex == 0)
    {
        
        [[[RKObjectManager sharedManager] HTTPClient] setDefaultHeader:@"versioDate" value:[version_date valueForKey:@"v1"]];
       
        NSLog(@"version1");
    }
    else if (control.selectedSegmentIndex == 1)
    {
        NSLog(@"version2");
        [[[RKObjectManager sharedManager] HTTPClient] setDefaultHeader:@"versioDate" value:[version_date valueForKey:@"v2"]];
        
    }
    else if (control.selectedSegmentIndex == 2)
    {
        [[[RKObjectManager sharedManager] HTTPClient] setDefaultHeader:@"versioDate" value:[version_date valueForKey:@"v3"]];
        

        NSLog(@"version3");
    }
    [prefs synchronize];
    NSString *tmpdate= [[[RKObjectManager sharedManager] defaultHeaders] valueForKey:@"versioDate"];
    NSLog(@"tmpdate===%@",tmpdate);
    
   
}

@end
