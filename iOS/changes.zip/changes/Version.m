//
//  Version.m
//  RestDemo
//
//  Created by jittu on 9/6/13.
//  Copyright (c) 2013 jittu. All rights reserved.
//

#import "Version.h"

@implementation Version

+(RKObjectMapping*)get_User_BasedonDate:(NSString *)date UserMapping:(RKObjectMapping*)UserMapping
{
    NSString *tmpdate= [[[RKObjectManager sharedManager] defaultHeaders] valueForKey:@"versioDate"];
    NSLog(@"tmpdate===%@",tmpdate);
    
   // RKObjectMapping *UserMapping;
   
  
    if([tmpdate isEqualToString:@"2013-06-01"])
    {
      UserMapping = [RKObjectMapping mappingForClass:[UserDetail class]];
    [UserMapping addAttributeMappingsFromArray:@[ @"firstName", @"middleName", @"lastName",@"userId" ]];
    }
    else if([tmpdate isEqualToString:@"2013-01-30"])
    {
        UserMapping = [RKObjectMapping mappingForClass:[UserDetail2 class]];
        [UserMapping addAttributeMappingsFromArray:@[ @"firstName", @"lastName",@"userId"]];
    }
    else if ([tmpdate isEqualToString:@"2012-07-01"])
    {
        UserMapping = [RKObjectMapping mappingForClass:[UserDetail3 class]];
        [UserMapping addAttributeMappingsFromArray:@[ @"firstName", @"middleName",@"lastName",@"address",@"userId"]];
    }
    NSLog(@"checking mapping here==%@",UserMapping);
    return UserMapping;
}

+(RKObjectMapping*)get_UserRequestMapping_Date:(NSString *)date UserMapping:(RKObjectMapping*)UserMapping
{
    NSString *tmpdate= [[[RKObjectManager sharedManager] defaultHeaders] valueForKey:@"versioDate"];
    NSLog(@"tmpdate===%@",tmpdate);
    
    // RKObjectMapping *UserMapping;
    
    
    if([tmpdate isEqualToString:@"2013-06-01"])
    {
    [UserMapping addAttributeMappingsFromArray:@[@"firstName",@"middleName",@"lastName",@"userId"]];
    }
    else if([tmpdate isEqualToString:@"2013-01-30"])
    {
        //UserMapping = [RKObjectMapping mappingForClass:[UserDetail2 class]];
        [UserMapping addAttributeMappingsFromArray:@[ @"firstName", @"lastName",@"userId"]];
    }
    else if ([tmpdate isEqualToString:@"2012-07-01"])
    {
        //UserMapping = [RKObjectMapping mappingForClass:[UserDetail3 class]];
        [UserMapping addAttributeMappingsFromArray:@[ @"firstName", @"middleName",@"lastName",@"address",@"userId"]];
    }
    NSLog(@"checking mapping here==%@",UserMapping);
    return UserMapping;
}

+(UserDetail *)get_UserObject_BasedonDate:(NSString *)fname mname:(NSString*)mname lname:(NSString *)lname userid:(NSString *)userid
{
        UserDetail *newsuer=[UserDetail new];
        [newsuer setFirstName:fname];
        [newsuer setMiddleName:mname];
        [newsuer setLastName:lname];
        if(userid!=nil)
        [newsuer setUserId:[userid intValue]];
    return newsuer;
    
}
+(UserDetail2 *)get_UserObject_BasedonDate:(NSString *)fname lname:(NSString *)lname userid:(NSString *)userid
{
    UserDetail2 *newsuer=[UserDetail2 new];
    [newsuer setFirstName:fname];
    [newsuer setLastName:lname];
    if(userid!=nil)
        [newsuer setUserId:[userid intValue]];
        return newsuer;
    
}
+(UserDetail3 *)get_UserObject_BasedonDate:(NSString *)fname mname:(NSString*)mname lname:(NSString *)lname address:(NSString *)address userid:(NSString *)userid
{
    UserDetail3 *newsuer=[UserDetail3 new];
    [newsuer setFirstName:fname];
    [newsuer setMiddleName:mname];
    [newsuer setLastName:lname];
    [newsuer setAddress:address];
    if(userid!=nil)
        [newsuer setUserId:[userid intValue]];
    return newsuer;
    
}


@end
