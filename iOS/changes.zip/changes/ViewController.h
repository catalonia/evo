//
//  ViewController.h
//  RestDemo
//
//  Created by jittu on 8/29/13.
//  Copyright (c) 2013 jittu. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ViewController : UIViewController<UITextFieldDelegate>
{
    IBOutlet UITextField *fname;
    IBOutlet UITextField *mname;
    IBOutlet UITextField *lname;
    IBOutlet UITextField *address;
    IBOutlet UILabel *newuser;
    IBOutlet UITextField *userid;
    IBOutlet UITextField *weburl;
    IBOutlet UISegmentedControl *segmentedControl;
    IBOutlet UITextField *pushmsg;
    NSDictionary *version_date;


}
-(IBAction)createUser:(id)sender;
-(IBAction)getUser:(id)sender;
- (IBAction)didChangeSegmentControl:(UISegmentedControl *)control;

@end
