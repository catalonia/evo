//
//  TokenViewController.h
//  RestDemo
//
//  Created by jittu on 9/11/13.
//  Copyright (c) 2013 jittu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
@interface TokenViewController : UIViewController
{
    IBOutlet UITextField *tokenAPI;
    IBOutlet UITextField *webAPI;
    IBOutlet UITextField *usernme;
    IBOutlet UIButton *submitbut;
}
@property (strong, nonatomic)ViewController *viewcontroller;
-(IBAction)getToken:(id)sender;


@end
