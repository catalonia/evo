//
//  TokenViewController.m
//  RestDemo
//
//  Created by jittu on 9/11/13.
//  Copyright (c) 2013 jittu. All rights reserved.
//

#import "TokenViewController.h"
#import <RestKit/RestKit.h>
#import "Token.h"


@interface TokenViewController ()

@end

@implementation TokenViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}


-(IBAction)getToken:(id)sender;
{
    [submitbut setEnabled:false];
    NSString *tokenurl=tokenAPI.text;
    NSString *Webapi=webAPI.text;
    
    if(tokenurl.length==0 || Webapi.length==0)
    {
        NSLog(@"Please enter all field");
        return;
    }
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];

    [prefs setObject:Webapi forKey:@"webAPI"];
    [prefs synchronize];
    
    
    
RKObjectManager *manager = [RKObjectManager managerWithBaseURL:[NSURL URLWithString:tokenurl]];
    [RKObjectManager setSharedManager:manager];
    [[manager HTTPClient] setAllowsInvalidSSLCertificate:TRUE];
    [[manager HTTPClient] setDefaultHeader:@"deviceToken" value:[prefs stringForKey:@"deviceToken"]];
    manager.requestSerializationMIMEType=RKMIMETypeJSON;
    RKObjectMapping* token = [RKObjectMapping mappingForClass:[Token class]];
    [token addAttributeMappingsFromDictionary:@{
     @"token": @"token",
     }];
    
    RKResponseDescriptor *tokenresponseDescriptor = [RKResponseDescriptor responseDescriptorWithMapping:token pathPattern:nil keyPath:nil statusCodes:RKStatusCodeIndexSetForClass(RKStatusCodeClassSuccessful)];
    
    [[RKObjectManager sharedManager] addResponseDescriptor:tokenresponseDescriptor];
    
    NSString *gettokenURL=[NSString stringWithFormat:NSLocalizedString(@"get_token_api", @""),[usernme text]];
    
    [manager getObjectsAtPath:gettokenURL parameters:nil success:^(RKObjectRequestOperation *operation, RKMappingResult *mappingResult) {
            [submitbut setEnabled:true];
        NSLog(@"mapping result==%@",mappingResult);
        Token *tmptok=mappingResult.firstObject;
        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
        [prefs setObject:tmptok.token forKey:@"token"];
        [prefs synchronize];
        NSLog(@"token==%@",tmptok.token);
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Token recevied" message:tmptok.token delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        
    self.viewcontroller=[[ViewController alloc] initWithNibName:@"ViewController" bundle:nil];
        [self.navigationController pushViewController:self.viewcontroller animated:YES];
        
    } failure:^(RKObjectRequestOperation *operation, NSError *error) {
        NSLog(@"check===%@",operation.description);
        RKLogError(@"Operation failed with error: %@", error);
    }];
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
